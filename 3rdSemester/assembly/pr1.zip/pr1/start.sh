nasm -f elf program.asm && gcc -m32 -o program program.o
./program